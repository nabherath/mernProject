const PaymentMethod = require ('../../models/paymentMethodModel');

// Create a new payment method
const createPaymentMethod = async (req, res) => {
  try {
    const { type, provider, accountNumber, expiryDate } = req.body;

    if (!type || !provider || !accountNumber) {
      return res.status(400).json({ success: false, message: "All required fields must be filled" });
    }
    const userId = req.userId;

    const newPaymentMethod = await PaymentMethod.create({ userId, type, provider, accountNumber, expiryDate });

    res.status(201).json({ success: true, message: "Payment method added successfully", data: newPaymentMethod });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to add payment method", error: error.message });
  }
};

// Get all payment methods for a user
const getPaymentMethods = async (req, res) => {
  try {
    const userId = req.userId;

    const paymentMethods = await PaymentMethod.find({ userId });

    res.status(200).json({ success: true, data: paymentMethods });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch payment methods", error: error.message });
  }
};

// Update a payment method
const updatePaymentMethod = async (req, res) => {
  try {
    const { id } = req.params; // Payment Method ID
    const { isDefault } = req.body;

    if (isDefault) {
      // Unset 'isDefault' for all other payment methods
      await PaymentMethod.updateMany({ isDefault: true }, { isDefault: false });
    }

    // Update the requested payment method
    const updatedPaymentMethod = await PaymentMethod.findByIdAndUpdate(
      id,
      { isDefault },
      { new: true } // Return the updated document
    );

    if (!updatedPaymentMethod) {
      return res.status(404).json({ success: false, message: "Payment method not found" });
    }

    res.status(200).json({
      success: true,
      message: "Payment method updated successfully",
      data: updatedPaymentMethod,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to update payment method",
      error: error.message,
    });
  }
};


// Delete a payment method
const deletePaymentMethod = async (req, res) => {
  try {
    const { id } = req.params; // Payment Method ID

    const deletedPaymentMethod = await PaymentMethod.findByIdAndDelete(id);

    if (!deletedPaymentMethod) {
      return res.status(404).json({ success: false, message: "Payment method not found" });
    }

    res.status(200).json({ success: true, message: "Payment method deleted successfully", data: deletedPaymentMethod });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete payment method", error: error.message });
  }
};

module.exports = {
  createPaymentMethod,
  getPaymentMethods,
  updatePaymentMethod,
  deletePaymentMethod,
};
