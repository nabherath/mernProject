const Category = require('../../models/categoryModel');

// Create a new category
const createCategory = async (req, res) => {
  try {
    const { label, value } = req.body;

    if (!label || !value) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }

    const newCategory = await Category.create({ label, value });

    res.status(201).json({ success: true, message: "Category created successfully", data: newCategory });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to create category", error: error.message });
  }
};

// Get all categories
const getCategories = async (req, res) => {
  try {
    const categories = await Category.find().sort({ createdAt: -1 });

    res.status(200).json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch categories", error: error.message });
  }
};

// Update a category
const updateCategory = async (req, res) => {
  try {
    const { id } = req.params; // Category ID
    const { label, value } = req.body;

    const updatedCategory = await Category.findByIdAndUpdate(
      id,
      { label, value },
      { new: true } // Return the updated document
    );

    if (!updatedCategory) {
      return res.status(404).json({ success: false, message: "Category not found" });
    }

    res.status(200).json({ success: true, message: "Category updated successfully", data: updatedCategory });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update category", error: error.message });
  }
};

// Delete a category
const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params; // Category ID

    const deletedCategory = await Category.findByIdAndDelete(id);

    if (!deletedCategory) {
      return res.status(404).json({ success: false, message: "Category not found" });
    }

    res.status(200).json({ success: true, message: "Category deleted successfully", data: deletedCategory });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete category", error: error.message });
  }
};

module.exports = {
  createCategory,
  getCategories,
  updateCategory,
  deleteCategory,
};
