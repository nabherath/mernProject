const Address = require('../../models/addressModel');

// Create a new address
const createAddress = async (req, res) => {
  try {
    const {userId, houseName, lane1, lane2, postalCode, phoneNumber } = req.body;

    if (!houseName || !lane1 || !postalCode || !phoneNumber) {
      return res.status(400).json({ success: false, message: "All required fields must be filled" });
    }

    const newAddress = await Address.create({ userId, houseName, lane1, lane2, postalCode, phoneNumber });

    res.status(201).json({ success: true, message: "Address added successfully", data: newAddress });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to add address", error: error.message });
  }
};

// Get all addresses for a user
const getAddresses = async (req, res) => {
  try {
    const userId = req.userId;
    
    const addresses = await Address.find({ userId });

    res.status(200).json({ success: true, data: addresses });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch addresses", error: error.message });
  }
};

// Update an address
const updateAddress = async (req, res) => {
  try {
    const { id } = req.params; // Address ID
    const { houseName, lane1, lane2, postalCode, phoneNumber } = req.body;

    const updatedAddress = await Address.findByIdAndUpdate(
      id,
      { houseName, lane1, lane2, postalCode, phoneNumber },
      { new: true } // Return the updated document
    );

    if (!updatedAddress) {
      return res.status(404).json({ success: false, message: "Address not found" });
    }

    res.status(200).json({ success: true, message: "Address updated successfully", data: updatedAddress });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update address", error: error.message });
  }
};

// Delete an address
const deleteAddress = async (req, res) => {
  try {
    const { id } = req.params; // Address ID

    const deletedAddress = await Address.findByIdAndDelete(id);

    if (!deletedAddress) {
      return res.status(404).json({ success: false, message: "Address not found" });
    }

    res.status(200).json({ success: true, message: "Address deleted successfully", data: deletedAddress });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete address", error: error.message });
  }
};

module.exports = {
  createAddress,
  getAddresses,
  updateAddress,
  deleteAddress,
};
