const Review = require('../../models/reviewModel');

// Create a new review
const createReview = async (req, res) => {
  try {
    const { review, productId } = req.body;

    if (!review || !productId) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }

    const authorId = req.userId;
    const authorName = req.userName;

    const newReview = await Review.create({ review, productId, authorId, authorName });

    res.status(201).json({ success: true, message: "Review created successfully", data: newReview });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to create review", error: error.message });
  }
};

// Get all reviews for a product
const getReviews = async (req, res) => {
  try {
    const { productId } = req.query;

    if (!productId) {
      return res.status(400).json({ success: false, message: "Product ID is required" });
    }

    const reviews = await Review.find({ productId });

    res.status(200).json({ success: true, data: reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch reviews", error: error.message });
  }
};

// Update a review
const updateReview = async (req, res) => {
  try {
    const { id } = req.params; // Review ID
    const { review } = req.body;
    console.log('params',req.body);
    

    if (!review) {
      return res.status(400).json({ success: false, message: "Review content is required" });
    }

    const updatedReview = await Review.findByIdAndUpdate(
      id,
      { review },
      { new: true } // Return the updated document
    );

    if (!updatedReview) {
      return res.status(404).json({ success: false, message: "Review not found" });
    }

    res.status(200).json({ success: true, message: "Review updated successfully", data: updatedReview });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update review", error: error.message });
  }
};

// Delete a review
const deleteReview = async (req, res) => {
  try {
    const { id } = req.params; // Review ID

    const deletedReview = await Review.findByIdAndDelete(id);

    if (!deletedReview) {
      return res.status(404).json({ success: false, message: "Review not found" });
    }

    res.status(200).json({ success: true, message: "Review deleted successfully", data: deletedReview });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete review", error: error.message });
  }
};

module.exports = {
  createReview,
  getReviews,
  updateReview,
  deleteReview,
};
