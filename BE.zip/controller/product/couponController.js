const Coupon = require('../../models/couponModel');

// Create a new coupon
const createCoupon = async (req, res) => {
  try {
    const { code, discount } = req.body;

    if (!code || !discount ) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }

    const newCoupon = await Coupon.create({ code, discount, isActive: true });

    res.status(201).json({ success: true, message: "Coupon created successfully", data: newCoupon });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to create coupon", error: error.message });
  }
};

// Get all coupons
const getCoupons = async (req, res) => {
  try {
    const coupons = await Coupon.find();

    res.status(200).json({ success: true, data: coupons });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch coupons", error: error.message });
  }
};


const updateCoupon = async (req, res) => {
  try {
    const { id } = req.params; // Coupon ID
    const { code, discount, isActive } = req.body;

    const updatedCoupon = await Coupon.findByIdAndUpdate(
      id,
      { code, discount, isActive },
      { new: true } // Return the updated document
    );

    if (!updatedCoupon) {
      return res.status(404).json({ success: false, message: "Coupon not found" });
    }

    res.status(200).json({ success: true, message: "Coupon updated successfully", data: updatedCoupon });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update coupon", error: error.message });
  }
};

// Delete a coupon
const deleteCoupon = async (req, res) => {
  try {
    const { id } = req.params; // Coupon ID

    const deletedCoupon = await Coupon.findByIdAndDelete(id);

    if (!deletedCoupon) {
      return res.status(404).json({ success: false, message: "Coupon not found" });
    }

    res.status(200).json({ success: true, message: "Coupon deleted successfully", data: deletedCoupon });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete coupon", error: error.message });
  }
};

const validateCoupon = async (req, res) => {
  try {
    const { code } = req.body;

    if (!code) {
      return res.status(400).json({ success: false, message: "Coupon code is required" });
    }

    const coupon = await Coupon.findOne({ code });

    if (!coupon) {
      return res.status(404).json({ success: false, message: "Invalid code" });
    }

    if (!coupon.isActive) {
      return res.status(400).json({ success: false, message: "Code expired" });
    }

    res.status(200).json({ success: true, message: "Valid code", discount: coupon.discount });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to validate coupon", error: error.message });
  }
};

module.exports = {
  createCoupon,
  getCoupons,
  updateCoupon,
  deleteCoupon,
  validateCoupon,
};
