const mongoose = require('mongoose');

const addressSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
    },
    houseName: {
      type: String,
      required: true,
      trim: true,
    },
    lane1: {
      type: String,
      required: true,
      trim: true,
    },
    lane2: {
      type: String,
      trim: true, // Optional field
    },
    postalCode: {
      type: String,
      required: true,
    },
    phoneNumber: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true, // Adds `createdAt` and `updatedAt` fields
  }
);

const Address = mongoose.model('Address', addressSchema);

module.exports = Address;
