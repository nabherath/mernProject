const mongoose = require('mongoose')


const reviewSchema = new mongoose.Schema({
    review : String,
    productId: String,
    authorId: String,
    authorName: String,
},{
    timestamps :true
})

const reviewModel = mongoose.model("review",reviewSchema)

module.exports = reviewModel