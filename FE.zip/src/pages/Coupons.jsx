import React, { useState } from 'react';
import { Button } from 'antd';
import { useGetCouponsQuery } from '../store/couponSlice';
import CouponList from '../components/Coupon/CouponList';
import AddCouponModal from '../components/Coupon/AddCouponModal';

const Coupons = () => {
  const { data: coupons, isLoading, error } = useGetCouponsQuery();
  const [isModalVisible, setIsModalVisible] = useState(false);

  if (isLoading) return <p>Loading coupons...</p>;
  if (error) return <p>Error loading coupons.</p>;

  return (
    <div className="p-4 w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Coupons</h2>
        <Button
          type="primary"
          className="bg-teal-600 hover:bg-teal-700"
          onClick={() => setIsModalVisible(true)}
        >
          Add Coupon
        </Button>
      </div>
      <div className="flex w-full justify-start">
    <div style={{ width: '35%' }}> 
      <CouponList coupons={coupons.data || []} />
    </div>
  </div>
      <AddCouponModal
        visible={isModalVisible}
        onClose={() => setIsModalVisible(false)}
      />
    </div>
  );
};

export default Coupons;
