import React, { useState } from 'react';
import { Button, Card, Modal, Form, Input } from 'antd';
import { 
  useGetCategoriesQuery, 
  useAddCategoryMutation, 
  useUpdateCategoryMutation, 
  useDeleteCategoryMutation 
} from '../store/categorySlice';
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import productCategory from '../helpers/productCategory';

const AllCategories = () => {
  const { data: categories, isLoading, error } = useGetCategoriesQuery();
  const [addCategory] = useAddCategoryMutation();
  const [updateCategory] = useUpdateCategoryMutation();
  const [deleteCategory] = useDeleteCategoryMutation();

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [form] = Form.useForm();
  const categoryList = categories?.data || [];
  const combinedCategories = [...categoryList, ...productCategory];

  const generateValueFromLabel = (label) =>
    label.toLowerCase().replace(/\s+/g, '-');

  const handleAddOrEdit = async (values) => {
    const value = generateValueFromLabel(values.label);
    const payload = { ...values, value };

    if (editingCategory) {
      await updateCategory({ id: editingCategory._id, updatedCategory: payload });
    } else {
      await addCategory(payload);
    }

    setEditingCategory(null);
    setIsModalVisible(false);
    form.resetFields(); // Clear the form after successful creation or update
  };

  const handleDelete = async (id) => {
    await deleteCategory(id);
  };

  if (isLoading) return <p>Loading categories...</p>;
  if (error) return <p>Error loading categories.</p>;

  return (
    <div className="p-4 w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Categories</h2>
        <Button
          type="primary"
          onClick={() => {
            setEditingCategory(null);
            setIsModalVisible(true);
            form.resetFields(); // Clear the form when opening the modal for a new category
          }}
          className='bg-teal-600'
        >
          Add Category
        </Button>
      </div>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '16px',
        }}
      >
        {combinedCategories.map((category) => (
          <Card
            key={category._id}
            style={{
              margin: '10px',
            }}
          >
            <>
            <div className=' flex justify-between'>
                <div>{category.label}</div>
                <div>
                <Button 
                  type="link" 
                  onClick={() => {
                    setEditingCategory(category);
                    setIsModalVisible(true);
                    form.setFieldsValue({ label: category.label }); 
                  }}
                >
                 <EditOutlined/>
                </Button>
                <Button type="link" danger onClick={() => handleDelete(category._id)}>
                  <DeleteOutlined/>
                </Button>
                </div>
            </div>
            
                
              </>
          </Card>
        ))}
      </div>
      <Modal
        title={editingCategory ? 'Edit Category' : 'Add Category'}
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <Form
          form={form}
          initialValues={{ label: '' }}
          onFinish={handleAddOrEdit}
        >
          <Form.Item
            name="label"
            label="Category Name"
            rules={[{ required: true, message: 'Please enter category name' }]}
          >
            <Input />
          </Form.Item>
          <div className="flex justify-end">
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: '8px' }}>
              Cancel
            </Button>
            <Button className='bg-teal-600' type="primary" htmlType="submit">
              {editingCategory ? 'Update' : 'Add'}
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default AllCategories;
