import { configureStore } from '@reduxjs/toolkit';
import userReducer from './userSlice'
import { productApi } from './productSlice';
import { couponApi } from './couponSlice';
import { addressApi } from './addressSlice';
import { paymentMethodApi } from './paymentMethodSlice';
import { categoryApi } from './categorySlice';


const store = configureStore({
  reducer: {
    user : userReducer,
    [productApi.reducerPath]: productApi.reducer,
    [couponApi.reducerPath]: couponApi.reducer,
    [addressApi.reducerPath]: addressApi.reducer,
    [paymentMethodApi.reducerPath]: paymentMethodApi.reducer,
    [categoryApi.reducerPath]: categoryApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
  .concat(productApi.middleware)
  .concat(couponApi.middleware)
  .concat(addressApi.middleware)
  .concat(paymentMethodApi.middleware)
  .concat(categoryApi.middleware),
});

export default store;