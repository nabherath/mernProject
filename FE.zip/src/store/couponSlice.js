import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const couponApi = createApi({
  reducerPath: 'couponApi',
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://localhost:8080/api', // Adjust base URL as needed
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('ecomAuth');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Coupons'],
  endpoints: (builder) => ({
    getCoupons: builder.query({
      query: () => 'coupons',
      providesTags: ['Coupons'],
    }),
    addCoupon: builder.mutation({
      query: (newCoupon) => ({
        url: 'coupons/create',
        method: 'POST',
        body: newCoupon,
      }),
      invalidatesTags: ['Coupons'],
    }),
    updateCouponStatus: builder.mutation({
      query: ({ id, isActive }) => ({
        url: `coupons/${id}`,
        method: 'PUT',
        body: { isActive },
      }),
      invalidatesTags: ['Coupons'],
    }),
    deleteCoupon: builder.mutation({
      query: (id) => ({
        url: `coupons/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Coupons'],
    }),
    deleteUser: builder.mutation({
      query: (id) => ({
        url: `delete-user/${id}`,
        method: 'DELETE',
      }),
    }),
    validateCoupon: builder.mutation({
      query: (couponCode) => ({
        url: 'coupons/validate',
        method: 'POST',
        body: { code: couponCode },
      }),
    }),
  }),
});

export const {
  useGetCouponsQuery,
  useAddCouponMutation,
  useUpdateCouponStatusMutation,
  useDeleteCouponMutation,
  useDeleteUserMutation,
  useValidateCouponMutation,
} = couponApi;
