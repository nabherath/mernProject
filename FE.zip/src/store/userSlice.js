import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    user : null
}
  
  export const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
     setUserDetails : (state,action)=>{
      state.user = action.payload
     }
    },
  });
  
  // Export the action creators
  export const { setUserDetails } = userSlice.actions;
  
  // Export the reducer to be used in the store
  export default userSlice.reducer