import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const productApi = createApi({
  reducerPath: 'reviewApi',
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://localhost:8080/api', // Adjust base URL as needed
    prepareHeaders: (headers ) => {
      const token = localStorage.getItem('ecomAuth');
      
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }

      return headers;
    },
  }),
  tagTypes: ['Reviews'],
  endpoints: (builder) => ({
    getReviews: builder.query({
      query: (productId) => `reviews?productId=${productId}`,
      providesTags: ['Reviews'],
    }),
    addReview: builder.mutation({
      query: (newReview) => ({
        url: 'reviews',
        method: 'POST',
        body: newReview,
      }),
      invalidatesTags: ['Reviews'],
    }),
    editReview: builder.mutation({
      query: ({ reviewId, updatedReview }) => {
        console.log('Review ID:', reviewId);
        console.log('Updated Review:', updatedReview); // Debugging: Ensure data is passed correctly
        return {
          url: `reviews/${reviewId}`,
          method: 'PUT',
          body: { review: updatedReview },
        };
      },
      invalidatesTags: ['Reviews'],
    }),
    deleteReview: builder.mutation({
      query: ({reviewId}) => ({
        url: `reviews/${reviewId}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Reviews'],
    }),
  }),
});

export const { useGetReviewsQuery, useAddReviewMutation, useDeleteReviewMutation, useEditReviewMutation } = productApi;
