import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const paymentMethodApi = createApi({
  reducerPath: 'paymentMethodApi',
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://localhost:8080/api', // Adjust base URL as needed
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('ecomAuth');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['PaymentMethods'],
  endpoints: (builder) => ({
    getPaymentMethods: builder.query({
      query: () => 'payment-methods',
      providesTags: ['PaymentMethods'],
    }),
    addPaymentMethod: builder.mutation({
      query: (newPaymentMethod) => ({
        url: 'payment-methods',
        method: 'POST',
        body: newPaymentMethod,
      }),
      invalidatesTags: ['PaymentMethods'],
    }),
    updatePaymentMethod: builder.mutation({
      query: ({ id, updatedPaymentMethod }) => ({
        url: `payment-methods/${id}`,
        method: 'PUT',
        body: updatedPaymentMethod,
      }),
      invalidatesTags: ['PaymentMethods'],
    }),
    deletePaymentMethod: builder.mutation({
      query: (id) => ({
        url: `payment-methods/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['PaymentMethods'],
    }),
  }),
});

export const {
  useGetPaymentMethodsQuery,
  useAddPaymentMethodMutation,
  useUpdatePaymentMethodMutation,
  useDeletePaymentMethodMutation,
} = paymentMethodApi;
