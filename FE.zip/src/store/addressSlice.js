import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const addressApi = createApi({
  reducerPath: 'addressApi',
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://localhost:8080/api', // Adjust base URL as needed
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('ecomAuth');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Addresses'],
  endpoints: (builder) => ({
    getAddresses: builder.query({
      query: () => 'addresses',
      providesTags: ['Addresses'],
    }),
    addAddress: builder.mutation({
      query: (newAddress) => ({
        url: 'addresses',
        method: 'POST',
        body: newAddress,
      }),
      invalidatesTags: ['Addresses'],
    }),
    updateAddress: builder.mutation({
      query: ({ id, updatedAddress }) => ({
        url: `addresses/${id}`,
        method: 'PUT',
        body: updatedAddress,
      }),
      invalidatesTags: ['Addresses'],
    }),
    deleteAddress: builder.mutation({
      query: (id) => ({
        url: `addresses/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Addresses'],
    }),
  }),
});

export const {
  useGetAddressesQuery,
  useAddAddressMutation,
  useUpdateAddressMutation,
  useDeleteAddressMutation,
} = addressApi;
