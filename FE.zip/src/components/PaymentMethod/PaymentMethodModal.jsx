import React, { useState } from 'react';
import { Modal, Form, Input, Radio, Tag, Button, Card } from 'antd';
import { CreditCardOutlined } from '@ant-design/icons';
import {
  useGetPaymentMethodsQuery,
  useAddPaymentMethodMutation,
  useDeletePaymentMethodMutation,
  useUpdatePaymentMethodMutation,
} from '../../store/paymentMethodSlice';

const PaymentMethodModal = ({ visible, onClose, onSelectPaymentMethod }) => {
  const [form] = Form.useForm();
  const [selectedMethod, setSelectedMethod] = useState(null);

  const { data: paymentMethodsData, isLoading } = useGetPaymentMethodsQuery();
  const [addPaymentMethod] = useAddPaymentMethodMutation();
  const [updatePaymentMethod] = useUpdatePaymentMethodMutation();
  const [deletePaymentMethod] = useDeletePaymentMethodMutation();

  const paymentMethods = paymentMethodsData?.data || [];

  const handleAdd = async (values) => {
    await addPaymentMethod(values).unwrap();
    form.resetFields();
  };

  const handleSetDefault = async (id) => {
    const updatedMethod = paymentMethods.find((method) => method._id === id);
    if (updatedMethod) {
      await updatePaymentMethod({ id, updatedPaymentMethod: { ...updatedMethod, isDefault: true } }).unwrap();
    }
  };

  const handleDelete = async (id) => {
    await deletePaymentMethod(id).unwrap();
  };

  function handleCardClick (method) {
    setSelectedMethod(method);
    onSelectPaymentMethod(method); 
    onClose();
  };

  return (
    <Modal
      visible={visible}
      onCancel={onClose}
      footer={null}
      title="Manage Payment Methods"
      width={800}
    >
      <div style={{ display: 'flex', gap: '20px' }}>
        {/* Left Half: Saved Payment Methods */}
        <div style={{ flex: 1, overflowY: 'auto', maxHeight: '400px' }}>
          {isLoading ? (
            <p>Loading...</p>
          ) : (
            paymentMethods.map((method) => (
              <Card
                key={method._id}
                style={{
                  marginBottom: '15px',
                  border:
                    selectedMethod?._id === method._id
                      ? '2px solid #52c41a'
                      : method.isDefault
                      ? '2px solid #1890ff'
                      : '1px solid #d9d9d9',
                  borderRadius: '8px',
                  cursor: 'pointer',
                }}
                onClick={() => handleCardClick(method)}
                bodyStyle={{ display: 'flex', flexDirection: 'column' }}
              >
                {/* Top Section */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <p className="text-xs">{method.type} card</p>
                    <p>
                      <CreditCardOutlined className="text-sm" />
                      &nbsp;&nbsp;{method.provider}
                    </p>
                    <p>**** **** **** {method.accountNumber.slice(-4)}</p>
                    {method.expiryDate && <p>Expiry: {method.expiryDate}</p>}
                  </div>
                  {/* Move Tag to the top-right corner */}
                  {method.isDefault && <Tag color="blue">Default</Tag>}
                </div>

                {/* Bottom Section */}
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '10px' }}>
                  {!method.isDefault && (
                    <Button type="link" onClick={(e) => {e.stopPropagation(); 
                    handleSetDefault(method._id)}}>
                      Set as Default
                    </Button>
                  )}
                  <Button type="link" danger onClick={(e) =>{e.stopPropagation();
                     handleDelete(method._id)}}>
                    Delete
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Right Half: Add Payment Method Form */}
        <div style={{ flex: 1 }}>
          <h3>{selectedMethod ? 'Edit Payment Method' : 'Add Payment Method'}</h3>
          <Form
            form={form}
            onFinish={handleAdd}
            layout="vertical"
            initialValues={selectedMethod || {}}
          >
            {/* Type Field */}
            <Form.Item name="type" label="Type" rules={[{ required: true, message: 'Please select a type' }]}>
              <Radio.Group>
                <Radio value="Debit">Debit</Radio>
                <Radio value="Credit">Credit</Radio>
              </Radio.Group>
            </Form.Item>

            {/* Provider Field */}
            <Form.Item
              name="provider"
              label="Provider"
              rules={[{ required: true, message: 'Please select a provider' }]}
            >
              <Radio.Group>
                <Radio value="Visa">Visa</Radio>
                <Radio value="MasterCard">MasterCard</Radio>
                <Radio value="PayPal">PayPal</Radio>
              </Radio.Group>
            </Form.Item>

            {/* Account Number Field */}
            <Form.Item
              name="accountNumber"
              label="Account Number"
              rules={[{ required: true, message: 'Please enter an account number' }]}
            >
              <Input placeholder="e.g., **** **** **** 1234" />
            </Form.Item>

            {/* Expiry Date Field */}
            <Form.Item name="expiryDate" label="Expiry Date">
              <Input placeholder="MM/YYYY" />
            </Form.Item>

            {/* Submit Button */}
            <Button className='bg-teal-600' type="primary" htmlType="submit" style={{ width: '100%' }}>
              Add Payment Method
            </Button>
          </Form>
        </div>
      </div>
    </Modal>
  );
};

export default PaymentMethodModal;
