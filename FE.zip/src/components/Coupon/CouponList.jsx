import React from 'react';
import { Button, Tag, Menu, Card, Dropdown } from 'antd';
import { MoreOutlined } from '@ant-design/icons';
import { useDeleteCouponMutation, useUpdateCouponStatusMutation } from '../../store/couponSlice';

const CouponList = ({ coupons }) => {
    const [deleteCoupon] = useDeleteCouponMutation();
    const [updateCouponStatus] = useUpdateCouponStatusMutation();

    const handleMenuClick = (e, couponId) => {
        if (e.key === 'activate') {
            updateCouponStatus({ id: couponId, status: 'active' });
        } else if (e.key === 'deactivate') {
            updateCouponStatus({ id: couponId, status: 'inactive' });
        } else if (e.key === 'delete') {
            deleteCoupon(couponId);
        }
    };

    const menu = (coupon) => (
        <Menu onClick={(e) => handleMenuClick(e, coupon._id)}>
            {coupon.status === 'inactive' && <Menu.Item key="activate">Activate</Menu.Item>}
            {coupon.status === 'active' && <Menu.Item key="deactivate">Deactivate</Menu.Item>}
            <Menu.Item key="delete">Delete</Menu.Item>
        </Menu>
    );

    const handleStatusChange = (couponId, isActive) => {
        console.log(isActive);
        
        updateCouponStatus({ id: couponId, isActive:isActive });
    };
    return (
        <div className="w-full mt-5 justify-start">
            {coupons.map((coupon) => (
                <Card
                    bordered
                    key={coupon._id}
                    className="mt-3"
                    title={`code: ${coupon.code}`}
                    extra={
                        <Dropdown overlay={menu(coupon)} trigger={['click']}>
                            <MoreOutlined />
                        </Dropdown>
                    }
                >
                    <div className='flex justify-between'>
                    <div className='m-3 block'>
                        <div className='mb-3'>
                        <Tag
                            className="text-sm font-medium "
                            color={coupon.isActive ? 'green' : 'red'}
                        >
                            {coupon.isActive ? 'Active' : 'Inactive'}
                        </Tag>
                        </div>
                        <div className='mt-3'>
                        <span>
                            Discount: {coupon.discount}%
                        </span>
                        </div>
                        
                        
                    </div>
                    <div>
                    <Button
                            type={coupon.isActive ? 'default' : 'primary'}
                            className="px-5 py-2 text-sm bg-teal-600 hover:bg-teal-700"
                            onClick={() => handleStatusChange(coupon._id, coupon.isActive ? false : true)}
                        >
                            {coupon.isActive ? 'Deactivate' : 'Activate'}
                        </Button>
                    </div>
                    </div>
                </Card>
            ))}
        </div>
    );
};

export default CouponList;
