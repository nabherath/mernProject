import React, { useState } from 'react';
import { Modal, Input, Button } from 'antd';
import { useAddCouponMutation } from '../../store/couponSlice';

const AddCouponModal = ({ visible, onClose }) => {
  const [code, setCode] = useState('');
  const [percentage, setPercentage] = useState('');
  const [addCoupon] = useAddCouponMutation();

  const handleAddCoupon = async () => {
    if (!code.trim()) return;
    try {
      await addCoupon({ code, status: 'inactive',discount:percentage }).unwrap();
      setCode('');
      setPercentage('');
      onClose();
    } catch (error) {
      console.error('Failed to add coupon:', error);
    }
  };

  return (
    <Modal
      title="Add New Coupon"
      open={visible}
      onCancel={onClose}
      footer={null}
    >
      <Input
        placeholder="Enter Promo Code"
        value={code}
        onChange={(e) => setCode(e.target.value)}
        className="mb-4"
      />
      <Input
        placeholder="Enter discount percentage"
        value={percentage}
        onChange={(e) => setPercentage(e.target.value)}
        className="mt-3"
      />
      <Button
        type="primary"
        onClick={handleAddCoupon}
        className="w-full bg-teal-600 hover:bg-teal-700 text-white mt-3"
      >
        Add Coupon
      </Button>
    </Modal>
  );
};

export default AddCouponModal;
