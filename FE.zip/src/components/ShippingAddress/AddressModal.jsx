import React, { useState, useEffect } from "react";
import { Modal, Form, Input } from "antd";
import {
  useGetAddressesQuery,
  useAddAddressMutation,
  useDeleteAddressMutation,
  useUpdateAddressMutation, // New mutation for updating addresses
} from "../../store/addressSlice";
import { useSelector } from "react-redux";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";

const AddressModal = ({ visible, onClose, onAddressSelect }) => {
  const [form] = Form.useForm();
  const [editForm] = Form.useForm(); // Separate form instance for editing
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [editingAddress, setEditingAddress] = useState(null);

  // RTK Query hooks
  const { data: addressesData, isLoading: isFetchingAddresses, refetch } = useGetAddressesQuery();
  const [addAddress, { isLoading: isAddingAddress }] = useAddAddressMutation();
  const [deleteAddress] = useDeleteAddressMutation();
  const [updateAddress, { isLoading: isUpdatingAddress }] = useUpdateAddressMutation();
  const user = useSelector((state) => state?.user?.user);

  // Fetch addresses from API
  const addresses = addressesData?.data || [];

  useEffect(() => {
    if (visible) {
      refetch();
    }
  }, [visible, refetch]);

  const handleAddAddress = async (values) => {
    const newAddress = {
      userId: user._id,
      houseName: values.houseName,
      lane1: values.lane1,
      lane2: values.lane2,
      postalCode: values.postalCode,
      phoneNumber: values.phone,
    };

    try {
      await addAddress(newAddress).unwrap(); 
      form.resetFields(); 
    } catch (error) {
      console.error("Failed to add address:", error.message);
    }
  };

  const handleEditClick = (address) => {
    setEditingAddress(address);
    editForm.setFieldsValue(address); // Pre-fill form with the selected address data
    setIsEditModalVisible(true);
  };

  const handleEditSave = async (values) => {
    try {
      const updatedAddress = { ...editingAddress, ...values };
      console.log(updatedAddress._id);
      
      await updateAddress({ id: updatedAddress._id, updatedAddress }).unwrap();
      setIsEditModalVisible(false); // Close the edit modal
      setEditingAddress(null); // Clear the editing state
    } catch (error) {
      console.error("Failed to update address:", error.message);
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteAddress(id).unwrap();
      console.log("Address deleted successfully");
    } catch (error) {
      console.error("Failed to delete address:", error.message);
    }
  };

  return (
    <Modal
      title="Select Address"
      visible={visible}
      onCancel={onClose}
      footer={null}
      width="50%"
      destroyOnClose
    >
      <div className="flex w-full justify-between">
        {/* Address List */}
        <div className="pr-4 border-r mr-5" style={{ width: "45%" }}>
          <h3 className="font-medium text-lg mb-2">Saved Addresses</h3>
          {isFetchingAddresses ? (
            <p>Loading addresses...</p>
          ) : (
            <ul className="space-y-2">
              {addresses.map((address, index) => (
                <li
                  key={index}
                  className="p-2 border rounded cursor-pointer hover:bg-gray-100 mt-3"
                  onClick={() => {
                    onAddressSelect(address);
                    onClose();
                  }}
                >
                  {`${address.houseName}, ${address.lane1}, ${address.lane2}, ${address.postalCode}, ${address.phoneNumber}`}

                  <div className="flex space-x-2">
                    <button
                      className="text-blue-500 hover:text-blue-700 ml-auto p-1 rounded-lg"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditClick(address);
                      }}
                    >
                      <EditOutlined className="text-sm" />
                    </button>
                    <button
                      className="text-red-400 hover:text-red-800 ml-3 p-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(address._id);
                      }}
                    >
                      <DeleteOutlined className="text-sm" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Address Form */}
        <div style={{ width: "45%" }} className="pl-4">
          <h3 className="font-medium text-lg mb-2">Add New Address</h3>
          <Form layout="vertical" form={form} onFinish={handleAddAddress}>
            <Form.Item
              label="House Name"
              name="houseName"
              rules={[{ required: true, message: "Please enter house name" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Lane 1"
              name="lane1"
              rules={[{ required: true, message: "Please enter lane 1" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Lane 2"
              name="lane2"
              rules={[{ required: true, message: "Please enter lane 2" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Postal Code"
              name="postalCode"
              rules={[{ required: true, message: "Please enter postal code" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Phone Number"
              name="phone"
              rules={[{ required: true, message: "Please enter phone number" }]}
            >
              <Input />
            </Form.Item>
            <button
              type="submit"
              className={`bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-700 ${
                isAddingAddress ? "opacity-50 cursor-not-allowed" : ""
              }`}
              disabled={isAddingAddress}
            >
              {isAddingAddress ? "Saving..." : "Add Address"}
            </button>
          </Form>
        </div>
      </div>

      {/* Edit Modal */}
      <Modal
        title="Edit Address"
        visible={isEditModalVisible}
        onCancel={() => setIsEditModalVisible(false)}
        onOk={() => editForm.submit()}
        confirmLoading={isUpdatingAddress}
      >
        <Form layout="vertical" form={editForm} onFinish={handleEditSave}>
          <Form.Item
            label="House Name"
            name="houseName"
            rules={[{ required: true, message: "Please enter house name" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Lane 1"
            name="lane1"
            rules={[{ required: true, message: "Please enter lane 1" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Lane 2"
            name="lane2"
            rules={[{ required: true, message: "Please enter lane 2" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Postal Code"
            name="postalCode"
            rules={[{ required: true, message: "Please enter postal code" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Phone Number"
            name="phoneNumber"
            rules={[{ required: true, message: "Please enter phone number" }]}
          >
            <Input />
          </Form.Item>
        </Form>
      </Modal>
    </Modal>
  );
};

export default AddressModal;
