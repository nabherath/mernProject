import React from 'react'

const Logo = ({w,h}) => {
  return (
   
<svg version="1.1" viewBox="0 0 900 900" width={w}  height={h} xmlns="http://www.w3.org/2000/svg">
<path transform="translate(0)" d="m0 0h900v900h-900z" fill="#32BEA5"/>
<path transform="translate(284,253)" d="m0 0h331l12 3 9 6 6 7 4 9 1 6v231h-342l-52-1v-221l1-16 6-11 9-8 9-4z" fill="#5B5E5F"/>
<path transform="translate(253,515)" d="m0 0h394l3 5 9 24 14 35 21 53 17 43-1 4-7 8-15 16-7 5-7 3-5 1h-441l-10-4-6-4-5-4v-2l-4-2-14-14-1-5 8-20 21-53 17-43 13-33 5-12z" fill="#FAFAFA"/>
<path transform="translate(899,487)" d="m0 0h1v413h-413v-1l37-6 37-8 25-7 30-11 23-10 17-8 23-13 24-15 18-13 14-11 14-12 17-16 11-11 7-8 13-15 13-17 10-14 10-15 10-17 14-26 7-16 6-13 12-34 8-29 7-36z" fill="#FAFAFA"/>
<path transform="translate(0,488)" d="m0 0 2 3 7 44 7 31 9 29 7 19 9 21 12 25 14 24 12 19 14 19 11 14 13 15 12 13 11 11 8 7 11 10 11 9 16 12 16 11 19 12 19 11 23 11 20 9 25 9 23 7 29 7 51 9v1h-411z" fill="#FAFAFA"/>
<path transform="translate(486)" d="m0 0h414v412h-1l-8-46-8-34-9-29-9-24-10-23-10-20-14-24-14-21-12-16-8-10-11-13-9-10-14-15-8-7-12-11-14-11-17-13-18-12-18-11-16-9-26-13-33-13-31-10-29-7-48-8-7-1z" fill="#FAFAFA"/>
<path transform="translate(0)" d="m0 0h411v1l-48 8-29 7-21 6-31 11-20 9-25 12-22 13-16 10-18 13-20 16-10 9-8 7-26 26-7 8-8 9-10 14h-2l-2 5-10 14-11 17-12 21-9 17-9 20-11 28-10 33-6 25-5 30-3 21-2 2z" fill="#FAFAFA"/>
<path transform="translate(604,254)" d="m0 0h17l10 4 9 8 6 12 1 6v230h-303l6-7 43-43 8-7 5-6 5-2 3 2 70-1 2-1 1-9-4-4-59-1-4-4-6-11v-2l82-1 6-4 14-27 11-24 2-9-44-2v-1l23-1 14-14 8-7 17-17 7-8 45-45h2v-2z" fill="#404041"/>
<path transform="translate(342,318)" d="m0 0h28l5 5 8 17 5 11 139 1 2 1-1 9-14 30-11 21-5 4-2 1h-82l8 15 2 1 59 1 5 5-1 9-3 2-70 1-5-5-7-14-15-36-13-31-12-29-1-1-20-1-4-2-2-5 1-6 3-3z" fill="#F9FAFA"/>
<path transform="translate(299,581)" d="m0 0h307l5 2v10l-4 3h-302l-7-2-1-1 1-11z" fill="#D0D4D7"/>
<path transform="translate(315,549)" d="m0 0h257l25 1 1 1v10l-2 2-4 1-43 1h-193l-39-1-7-3-1-1v-5l4-5z" fill="#D0D4D7"/>
<path transform="translate(457,622)" d="m0 0h37l6 3 3 5 5 15v6l-2 1-16 1-100-1-3-2 1-6 8-16 4-4 4-1z" fill="#D0D4D7"/>
<path transform="translate(421,458)" d="m0 0h8l5 3 4 8-1 7-5 5-3 2h-9l-5-5-3-5 1-7 4-6z" fill="#F6F7F7"/>
<path transform="translate(467,458)" d="m0 0h7l5 3 4 5v8l-3 5-5 4h-9l-6-5-2-4v-7l4-6z" fill="#F7F8F8"/>
<path transform="translate(414,418)" d="m0 0h80v1l-59 1v1l-5 1 3 1h-2l1 3-3 4h-2l1 3 54 1v1h-58l-4-4-6-11z" fill="#566665"/>
</svg>

  )
}

export default Logo