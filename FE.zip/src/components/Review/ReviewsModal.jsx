import React, { useState } from 'react';
import { Modal, List, Input, Button, Dropdown, Menu, Space, message } from 'antd';
import { MoreOutlined } from '@ant-design/icons';
import { useGetReviewsQuery, useAddReviewMutation, useEditReviewMutation, useDeleteReviewMutation } from '../../store/productSlice';
import { useSelector } from 'react-redux';

const { TextArea } = Input;

const ReviewModal = ({ visible, onClose, productId }) => {
  const { data: reviewData, isLoading, error } = useGetReviewsQuery(productId, {
    skip: !visible, // Fetch reviews only when the modal is visible
  });

  const user = useSelector((state) => state?.user?.user);
  
  
  const [addReview] = useAddReviewMutation();
  const [editReview] = useEditReviewMutation();
  const [deleteReview] = useDeleteReviewMutation();

  const [newReview, setNewReview] = useState('');
  const [editingReviewId, setEditingReviewId] = useState(null);
  const [editingReviewText, setEditingReviewText] = useState('');

  // Add a new review
  const handleAddReview = async () => {
    if (!newReview.trim()) {
      return; // Prevent submitting empty reviews
    }
    try {
      await addReview({ productId, review: newReview }).unwrap();
      setNewReview('');
      message.success('Review added successfully');
    } catch (err) {
      console.error('Error adding review:', err);
      message.error('Failed to add review');
    }
  };

  // Save the edited review
  const handleSaveEdit = async () => {
    if (!editingReviewText.trim()) {
      return;
    }
    try {
      console.log(editingReviewText);
      
      await editReview({ reviewId: editingReviewId, updatedReview: editingReviewText }).unwrap();
      setEditingReviewId(null);
      setEditingReviewText('');
      message.success('Review updated successfully');
    } catch (err) {
      console.error('Error editing review:', err);
      message.error('Failed to update review');
    }
  };

  // Delete a review
  const handleDeleteReview = async (reviewId) => {
    try {
      await deleteReview({ reviewId }).unwrap();
      message.success('Review deleted successfully');
    } catch (err) {
      console.error('Error deleting review:', err);
      message.error('Failed to delete review');
    }
  };

  // Handle menu actions (edit/delete)
  const handleMenuClick = (e, reviewId, reviewText) => {
    if (e.key === 'edit') {
      setEditingReviewId(reviewId);
      setEditingReviewText(reviewText);
    } else if (e.key === 'delete') {
      handleDeleteReview(reviewId);
    }
  };

  return (
    <Modal
  title="Reviews"
  open={visible}
  onCancel={onClose}
  footer={null}
>
  {isLoading && <p className="text-center text-gray-500">Loading reviews...</p>}
  {error && <p className="text-center text-red-500">Error loading reviews.</p>}

  <List
    dataSource={reviewData?.data || []}
    renderItem={(item) => (
      <List.Item>
        <div className="w-full border-b border-gray-200 pb-4 mb-4">
          {/* Author Section */}
          <div className="flex justify-between items-center">
            <div className="text-base !text-gray-300 font-medium capitalize">
              <span className='mr-4'>
              {item.authorName}
              </span>
              <span className="text-xs text-gray-300 pl-4">
              &nbsp;&nbsp;&nbsp;
              {new Date(item.createdAt).toLocaleDateString()}
              </span>
            </div>
            {item.authorId === user._id && (
              <Dropdown
                overlay={
                  <Menu onClick={(e) => handleMenuClick(e, item._id, item.review)}>
                    <Menu.Item key="edit">Edit</Menu.Item>
                    <Menu.Item key="delete">Delete</Menu.Item>
                  </Menu>
                }
              >
                <button
                  onClick={(e) => e.preventDefault()}
                  className="text-gray-400 hover:text-gray-600 focus:outline-none"
                >
                  <MoreOutlined />
                </button>
              </Dropdown>
            )}
          </div>

          {/* Review Text */}
          <div className="mt-2 text-gray-700 text-sm">
            {editingReviewId === item._id ? (
              <div>
                <TextArea
                  rows={2}
                  value={editingReviewText}
                  onChange={(e) => setEditingReviewText(e.target.value)}
                  className="mt-2 w-full border border-gray-300 rounded-md"
                />
                <Space className="mt-3">
                  <Button
                    className="border border-teal-600 rounded px-3 py-1 min-w-[120px] text-white bg-teal-600 font-medium hover:text-teal-600 hover:bg-white"
                    type="primary"
                    onClick={handleSaveEdit}
                  >
                    Save
                  </Button>
                  <Button
                    className="border border-teal-600 rounded px-3 py-1 min-w-[120px] text-teal-700 font-medium hover:bg-teal-600 hover:text-white"
                    onClick={() => setEditingReviewId(null)}
                  >
                    Cancel
                  </Button>
                </Space>
              </div>
            ) : (
              <p>{item.review}</p>
            )}
          </div>
        </div>
      </List.Item>
    )}
  />

  {/* Input field for new review */}
  <div className="mt-4">
    <TextArea
      className="w-full border border-gray-300 rounded-md"
      rows={2}
      placeholder="Write a new review..."
      value={newReview}
      onChange={(e) => setNewReview(e.target.value)}
    />
    <Button
      className="border border-teal-600 rounded px-3 py-1 mt-3 text-white bg-teal-600 font-medium hover:text-teal-600 hover:bg-white"
      type="primary"
      onClick={handleAddReview}
    >
      Add Review
    </Button>
  </div>
</Modal>

  );
};

export default ReviewModal;
